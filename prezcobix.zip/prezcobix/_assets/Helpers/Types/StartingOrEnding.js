var StartingOrEndingTypes = {
  STATE_STARTING: "state_starting",
  STATE_ENDING: "state_ending",
  STATE_NO_MATCH: "state_no_match"
};
